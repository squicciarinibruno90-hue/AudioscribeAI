package com.vilma.audioscribe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.mlkit.genai.common.FeatureStatus;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK_VIDEO = 1001;
    private static final String PREFS = "audioscribe_prefs";
    private static final String PREF_GLOSSARY = "glossary";
    private static final String DEFAULT_GLOSSARY =
            "Universal Design for Learning\nCAST\nICF\nICD-H\nPEI\nCapability Approach\n" +
            "Disability Studies\nEvidence-Based Education\nfacilitatori\nbarriere\nfunzionamenti\n" +
            "capacitazione\ncapacitazioni\nSen\nNussbaum\nUNESCO";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Uri selectedVideoUri;
    private MediaInfo selectedVideoInfo;
    private File extractedAudioFile;
    private String originalTranscript = "";
    private String lastSavedBaseName = "trascrizione";

    private VideoView videoView;
    private TextView infoText;
    private TextView statusText;
    private TextView aiStatusText;
    private ProgressBar progressBar;
    private EditText transcriptEdit;
    private Button pickButton;
    private Button extractButton;
    private Button saveAudioButton;
    private Button transcribeButton;
    private Button stopTranscribeButton;
    private Button cleanAiButton;
    private Button originalButton;
    private Button copyButton;
    private Button copyChatGptButton;
    private Button saveTxtButton;
    private Button shareButton;

    private SpeechRecognizer speechRecognizer;
    private ParcelFileDescriptor speechReadSide;
    private ParcelFileDescriptor speechWriteSide;
    private volatile boolean transcriptionActive = false;
    private final StringBuilder recognizedText = new StringBuilder();
    private String lastRecognizedSegment = "";
    private PowerManager.WakeLock wakeLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildUi();
        checkAiAvailability();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("AudioScribe AI");
        title.setTextSize(28f);
        title.setTextColor(Color.rgb(30, 30, 30));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Video → audio → trascrizione → pulizia AI locale");
        subtitle.setTextSize(15f);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        aiStatusText = new TextView(this);
        aiStatusText.setText("AI locale: verifica in corso…");
        aiStatusText.setTextSize(13f);
        aiStatusText.setPadding(0, 0, 0, dp(12));
        root.addView(aiStatusText);

        pickButton = button("Seleziona video dalla galleria");
        root.addView(pickButton);
        pickButton.setOnClickListener(v -> pickVideo());

        videoView = new VideoView(this);
        videoView.setVisibility(View.GONE);
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        videoLp.topMargin = dp(12);
        root.addView(videoView, videoLp);
        videoView.setOnClickListener(v -> {
            if (videoView.isPlaying()) videoView.pause(); else videoView.start();
        });

        infoText = new TextView(this);
        infoText.setTextSize(14f);
        infoText.setPadding(0, dp(10), 0, dp(10));
        root.addView(infoText);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(12)));

        statusText = new TextView(this);
        statusText.setText("Seleziona un video per iniziare.");
        statusText.setTextSize(14f);
        statusText.setPadding(0, dp(8), 0, dp(10));
        root.addView(statusText);

        extractButton = button("Estrai audio");
        extractButton.setEnabled(false);
        root.addView(extractButton);
        extractButton.setOnClickListener(v -> extractAudio());

        LinearLayout audioRow = horizontalRow();
        saveAudioButton = button("Salva audio");
        saveAudioButton.setEnabled(false);
        transcribeButton = button("Trascrivi");
        transcribeButton.setEnabled(false);
        audioRow.addView(saveAudioButton, weighted());
        audioRow.addView(transcribeButton, weighted());
        root.addView(audioRow);
        saveAudioButton.setOnClickListener(v -> saveAudio());
        transcribeButton.setOnClickListener(v -> startTranscription());

        stopTranscribeButton = button("Interrompi trascrizione");
        stopTranscribeButton.setEnabled(false);
        root.addView(stopTranscribeButton);
        stopTranscribeButton.setOnClickListener(v -> stopTranscription("Trascrizione interrotta."));

        TextView transcriptTitle = new TextView(this);
        transcriptTitle.setText("Trascrizione");
        transcriptTitle.setTextSize(20f);
        transcriptTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        transcriptTitle.setPadding(0, dp(20), 0, dp(8));
        root.addView(transcriptTitle);

        transcriptEdit = new EditText(this);
        transcriptEdit.setHint("La trascrizione comparirà qui. Puoi modificarla manualmente.");
        transcriptEdit.setGravity(Gravity.TOP | Gravity.START);
        transcriptEdit.setTextSize(16f);
        transcriptEdit.setMinLines(12);
        transcriptEdit.setBackgroundColor(Color.rgb(247, 247, 247));
        transcriptEdit.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(transcriptEdit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout aiRow = horizontalRow();
        cleanAiButton = button("Pulisci con AI");
        originalButton = button("Originale");
        aiRow.addView(cleanAiButton, weighted());
        aiRow.addView(originalButton, weighted());
        root.addView(aiRow);
        cleanAiButton.setOnClickListener(v -> cleanWithAi());
        originalButton.setOnClickListener(v -> {
            if (originalTranscript.isEmpty()) toast("Non c'è ancora una trascrizione originale.");
            else transcriptEdit.setText(originalTranscript);
        });

        Button glossaryButton = button("Glossario termini universitari");
        root.addView(glossaryButton);
        glossaryButton.setOnClickListener(v -> editGlossary());

        LinearLayout copyRow = horizontalRow();
        copyButton = button("Copia tutto");
        copyChatGptButton = button("Copia per ChatGPT");
        copyRow.addView(copyButton, weighted());
        copyRow.addView(copyChatGptButton, weighted());
        root.addView(copyRow);
        copyButton.setOnClickListener(v -> copyTranscript(false));
        copyChatGptButton.setOnClickListener(v -> copyTranscript(true));

        LinearLayout saveRow = horizontalRow();
        saveTxtButton = button("Salva TXT");
        shareButton = button("Condividi testo");
        saveRow.addView(saveTxtButton, weighted());
        saveRow.addView(shareButton, weighted());
        root.addView(saveRow);
        saveTxtButton.setOnClickListener(v -> saveTxt());
        shareButton.setOnClickListener(v -> shareText());

        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15f);
        b.setMinHeight(dp(48));
        return b;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, 0);
        return row;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void pickVideo() {
        Intent intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
        intent.setType("video/*");
        try {
            startActivityForResult(intent, REQ_PICK_VIDEO);
        } catch (ActivityNotFoundException e) {
            Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType("video/*");
            startActivityForResult(fallback, REQ_PICK_VIDEO);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_VIDEO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        selectedVideoUri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(selectedVideoUri, flags);
        } catch (Exception ignored) {}

        extractedAudioFile = null;
        originalTranscript = "";
        transcriptEdit.setText("");
        saveAudioButton.setEnabled(false);
        transcribeButton.setEnabled(false);
        selectedVideoInfo = MediaUtils.inspectVideo(this, selectedVideoUri);
        lastSavedBaseName = stripExtension(selectedVideoInfo.displayName);
        infoText.setText(selectedVideoInfo.displayName + "\n" +
                MediaUtils.formatDuration(selectedVideoInfo.durationMs) + " • " +
                MediaUtils.formatBytes(selectedVideoInfo.sizeBytes) +
                (selectedVideoInfo.width > 0 ? " • " + selectedVideoInfo.width + "×" + selectedVideoInfo.height : ""));

        videoView.setVisibility(View.VISIBLE);
        videoView.setVideoURI(selectedVideoUri);
        videoView.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            videoView.seekTo(Math.min(300, Math.max(1, mp.getDuration() / 20)));
            videoView.pause();
        });
        extractButton.setEnabled(true);
        status("Video selezionato. Tocca l'anteprima per riprodurlo oppure estrai l'audio.");
    }

    private void extractAudio() {
        if (selectedVideoUri == null) return;
        setBusyForExtraction(true);
        progress(0, true);
        status("Estrazione audio…");
        acquireWakeLock();
        File out = new File(getCacheDir(), "audioscribe_current.m4a");
        worker.execute(() -> {
            try {
                File result = VideoAudioExtractor.extract(this, selectedVideoUri, out,
                        p -> runOnUiThread(() -> progress(p, true)));
                extractedAudioFile = result;
                runOnUiThread(() -> {
                    progress(100, true);
                    status("Audio pronto: " + MediaUtils.formatBytes(result.length()));
                    saveAudioButton.setEnabled(true);
                    transcribeButton.setEnabled(true);
                    setBusyForExtraction(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress(0, false);
                    status("Errore estrazione: " + safeMessage(e));
                    setBusyForExtraction(false);
                });
            } finally {
                releaseWakeLock();
            }
        });
    }

    private void saveAudio() {
        File audio = extractedAudioFile;
        if (audio == null || !audio.exists()) return;
        status("Salvataggio audio…");
        worker.execute(() -> {
            try {
                Uri saved = MediaUtils.saveAudioToMusic(this, audio, lastSavedBaseName + "_audio.m4a");
                runOnUiThread(() -> {
                    status("Audio salvato in Musica/AudioScribe AI.");
                    toast("Audio salvato");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status("Errore salvataggio audio: " + safeMessage(e)));
            }
        });
    }

    private void startTranscription() {
        if (transcriptionActive) return;
        File audio = extractedAudioFile;
        if (audio == null || !audio.exists()) {
            toast("Prima estrai l'audio.");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("Sul telefono non risulta disponibile alcun servizio di riconoscimento vocale.");
            return;
        }

        cleanupRecognizer();
        recognizedText.setLength(0);
        lastRecognizedSegment = "";
        transcriptEdit.setText("");
        originalTranscript = "";
        transcriptionActive = true;
        stopTranscribeButton.setEnabled(true);
        transcribeButton.setEnabled(false);
        cleanAiButton.setEnabled(false);
        progress(0, true);
        status("Preparazione trascrizione locale…");
        acquireWakeLock();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        try {
            ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            speechReadSide = pipe[0];
            speechWriteSide = pipe[1];

            boolean onDevice = SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
            speechRecognizer = onDevice
                    ? SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                    : SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(createRecognitionListener());

            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_QUALITY);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, speechReadSide);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16_000);
            intent.putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION, RecognizerIntent.EXTRA_AUDIO_SOURCE);

            ArrayList<String> bias = glossaryList();
            if (!bias.isEmpty()) intent.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, bias);

            speechRecognizer.startListening(intent);
            status(onDevice
                    ? "Trascrizione con riconoscimento on-device…"
                    : "Trascrizione con il riconoscitore disponibile sul sistema…");

            worker.execute(() -> {
                try {
                    Pcm16kPipeStreamer.stream(audio, speechWriteSide,
                            p -> runOnUiThread(() -> progress(p, true)));
                    speechWriteSide = null; // AutoCloseOutputStream has closed it.
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        status("Errore durante la lettura dell'audio: " + safeMessage(e));
                        stopTranscription("Trascrizione terminata per errore.");
                    });
                }
            });
        } catch (Exception e) {
            status("Impossibile avviare la trascrizione: " + safeMessage(e));
            finishTranscription(false);
        }
    }

    private RecognitionListener createRecognitionListener() {
        return new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                status("Riconoscitore pronto. Elaborazione dell'audio in corso…");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override public void onError(int error) {
                // ERROR_NO_MATCH can occur at the end of a long segmented session even after useful segments.
                boolean haveText = recognizedText.length() > 0;
                if (haveText && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    finishTranscription(true);
                } else {
                    status("Errore riconoscimento: " + speechError(error));
                    finishTranscription(haveText);
                }
            }

            @Override public void onResults(Bundle results) {
                appendRecognitionBundle(results);
                finishTranscription(recognizedText.length() > 0);
            }

            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    String preview = list.get(0);
                    String base = recognizedText.toString();
                    transcriptEdit.setText(base + (base.isEmpty() ? "" : "\n\n") + preview);
                    transcriptEdit.setSelection(transcriptEdit.length());
                }
            }

            @Override public void onEvent(int eventType, Bundle params) {}

            @Override public void onSegmentResults(Bundle segmentResults) {
                appendRecognitionBundle(segmentResults);
            }

            @Override public void onEndOfSegmentedSession() {
                finishTranscription(recognizedText.length() > 0);
            }

            @Override public void onLanguageDetection(Bundle results) {}
        };
    }

    private void appendRecognitionBundle(Bundle bundle) {
        if (bundle == null) return;
        ArrayList<String> list = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list == null || list.isEmpty()) return;
        String text = list.get(0) == null ? "" : list.get(0).trim();
        if (text.isEmpty()) return;
        if (text.equals(lastRecognizedSegment)) return;
        // Some recognizers return a final result that repeats the final segment.
        String current = recognizedText.toString();
        if (current.endsWith(text)) {
            lastRecognizedSegment = text;
            return;
        }
        if (recognizedText.length() > 0) recognizedText.append("\n\n");
        recognizedText.append(text);
        lastRecognizedSegment = text;
        transcriptEdit.setText(recognizedText.toString());
        transcriptEdit.setSelection(transcriptEdit.length());
    }

    private void finishTranscription(boolean success) {
        if (!transcriptionActive) return;
        transcriptionActive = false;
        stopTranscribeButton.setEnabled(false);
        transcribeButton.setEnabled(extractedAudioFile != null);
        cleanAiButton.setEnabled(true);
        progress(success ? 100 : progressBar.getProgress(), success);
        String finalText = recognizedText.toString().trim();
        if (!finalText.isEmpty()) {
            originalTranscript = finalText;
            transcriptEdit.setText(finalText);
            transcriptEdit.setSelection(transcriptEdit.length());
            status("Trascrizione completata. Puoi modificarla, copiarla o pulirla con l'AI locale.");
        } else if (success) {
            status("Trascrizione terminata, ma non è stato riconosciuto testo.");
        }
        cleanupRecognizer();
        releaseWakeLock();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void stopTranscription(String message) {
        if (!transcriptionActive) return;
        try { if (speechRecognizer != null) speechRecognizer.cancel(); } catch (Exception ignored) {}
        closeQuietly(speechWriteSide);
        speechWriteSide = null;
        status(message);
        finishTranscription(recognizedText.length() > 0);
    }

    private void cleanupRecognizer() {
        closeQuietly(speechReadSide);
        closeQuietly(speechWriteSide);
        speechReadSide = null;
        speechWriteSide = null;
        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
            speechRecognizer = null;
        }
    }

    private void cleanWithAi() {
        String current = transcriptEdit.getText().toString().trim();
        if (current.isEmpty()) {
            toast("Non c'è testo da pulire.");
            return;
        }
        if (originalTranscript.isEmpty()) originalTranscript = current;
        cleanAiButton.setEnabled(false);
        progress(0, true);
        status("Avvio Gemini Nano sul dispositivo…");
        acquireWakeLock();
        worker.execute(() -> {
            try (TranscriptCleaner cleaner = new TranscriptCleaner(this)) {
                String cleaned = cleaner.clean(current, getGlossary(), new TranscriptCleaner.StatusCallback() {
                    @Override public void onStatus(String message) {
                        runOnUiThread(() -> status(message));
                    }
                    @Override public void onProgress(int currentBlock, int totalBlocks) {
                        int p = (int) Math.round((currentBlock - 1) * 100.0 / Math.max(1, totalBlocks));
                        runOnUiThread(() -> progress(p, true));
                    }
                });
                runOnUiThread(() -> {
                    transcriptEdit.setText(cleaned);
                    transcriptEdit.setSelection(transcriptEdit.length());
                    progress(100, true);
                    status("Pulizia AI completata. L'originale resta disponibile con il pulsante “Originale”.");
                    cleanAiButton.setEnabled(true);
                });
            } catch (Exception e) {
                String fallback = TranscriptCleaner.basicCleanup(current, getGlossary());
                runOnUiThread(() -> {
                    transcriptEdit.setText(fallback);
                    transcriptEdit.setSelection(transcriptEdit.length());
                    cleanAiButton.setEnabled(true);
                    progress(0, false);
                    status("Gemini Nano non disponibile in questo momento. Applicata pulizia locale di base. Dettaglio: " + safeMessage(e));
                });
            } finally {
                releaseWakeLock();
            }
        });
    }

    private void checkAiAvailability() {
        worker.execute(() -> {
            String label;
            try (TranscriptCleaner cleaner = new TranscriptCleaner(this)) {
                int status = cleaner.checkStatus();
                if (status == FeatureStatus.AVAILABLE) {
                    label = "AI locale: Gemini Nano pronto";
                } else if (status == FeatureStatus.DOWNLOADABLE) {
                    label = "AI locale: Gemini Nano supportato; modello scaricabile al primo uso";
                } else if (status == FeatureStatus.DOWNLOADING) {
                    label = "AI locale: download di Gemini Nano in corso";
                } else {
                    label = "AI locale: non disponibile nella configurazione attuale; resterà la pulizia di base";
                }
            } catch (Exception e) {
                label = "AI locale: verifica non riuscita; sarà riprovata quando la userai";
            }
            String finalLabel = label;
            runOnUiThread(() -> aiStatusText.setText(finalLabel));
        });
    }

    private void editGlossary() {
        final EditText edit = new EditText(this);
        edit.setText(getGlossary());
        edit.setMinLines(10);
        edit.setGravity(Gravity.TOP | Gravity.START);
        int pad = dp(14);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(pad, 0, pad, 0);
        box.addView(edit, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Glossario")
                .setMessage("Un termine per riga. Verrà usato come suggerimento nella trascrizione e nella pulizia AI.")
                .setView(box)
                .setPositiveButton("Salva", (d, which) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString(PREF_GLOSSARY, edit.getText().toString().trim()).apply();
                    toast("Glossario salvato");
                })
                .setNeutralButton("Ripristina", (d, which) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString(PREF_GLOSSARY, DEFAULT_GLOSSARY).apply();
                    toast("Glossario ripristinato");
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    private String getGlossary() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        return p.getString(PREF_GLOSSARY, DEFAULT_GLOSSARY);
    }

    private ArrayList<String> glossaryList() {
        ArrayList<String> list = new ArrayList<>();
        for (String line : getGlossary().split("[,;\\n]")) {
            String s = line.trim();
            if (!s.isEmpty() && s.length() <= 100) list.add(s);
        }
        return list;
    }

    private void copyTranscript(boolean forChatGpt) {
        String text = transcriptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            toast("Non c'è testo da copiare.");
            return;
        }
        if (forChatGpt) {
            text = "Sistema questa trascrizione universitaria mantenendo integralmente tutti i contenuti. " +
                    "Correggi gli errori di riconoscimento vocale e la terminologia, aggiungi punteggiatura e paragrafi, " +
                    "ma non fare un riassunto e non aggiungere informazioni non presenti.\n\n" + text;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(forChatGpt ? "Trascrizione per ChatGPT" : "Trascrizione", text));
        toast(forChatGpt ? "Testo + istruzione copiati" : "Trascrizione copiata");
    }

    private void saveTxt() {
        String text = transcriptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            toast("Non c'è testo da salvare.");
            return;
        }
        status("Salvataggio TXT…");
        worker.execute(() -> {
            try {
                MediaUtils.saveTextToDownloads(this, text, lastSavedBaseName + "_trascrizione.txt");
                runOnUiThread(() -> {
                    status("TXT salvato in Download/AudioScribe AI.");
                    toast("TXT salvato");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status("Errore salvataggio TXT: " + safeMessage(e)));
            }
        });
    }

    private void shareText() {
        String text = transcriptEdit.getText().toString().trim();
        if (text.isEmpty()) {
            toast("Non c'è testo da condividere.");
            return;
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Condividi trascrizione"));
    }

    private void setBusyForExtraction(boolean busy) {
        pickButton.setEnabled(!busy && !transcriptionActive);
        extractButton.setEnabled(!busy && selectedVideoUri != null && !transcriptionActive);
        if (busy) {
            saveAudioButton.setEnabled(false);
            transcribeButton.setEnabled(false);
        } else if (extractedAudioFile != null) {
            saveAudioButton.setEnabled(true);
            transcribeButton.setEnabled(!transcriptionActive);
        }
    }

    private void progress(int value, boolean visible) {
        progressBar.setVisibility(visible ? View.VISIBLE : View.GONE);
        progressBar.setProgress(Math.max(0, Math.min(100, value)));
    }

    private void status(String s) {
        statusText.setText(s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String stripExtension(String name) {
        if (name == null || name.trim().isEmpty()) return "trascrizione";
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String safeMessage(Throwable t) {
        String m = t.getMessage();
        return (m == null || m.trim().isEmpty()) ? t.getClass().getSimpleName() : m;
    }

    private static String speechError(int e) {
        switch (e) {
            case SpeechRecognizer.ERROR_AUDIO: return "problema audio";
            case SpeechRecognizer.ERROR_CLIENT: return "errore del client";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "permessi insufficienti";
            case SpeechRecognizer.ERROR_NETWORK: return "errore di rete del riconoscitore";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "timeout di rete";
            case SpeechRecognizer.ERROR_NO_MATCH: return "nessun testo riconosciuto";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "riconoscitore occupato";
            case SpeechRecognizer.ERROR_SERVER: return "errore del servizio di riconoscimento";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "nessun parlato rilevato";
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "servizio disconnesso";
            case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS: return "troppe richieste";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "italiano non supportato dal riconoscitore installato";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "modello italiano non disponibile";
            default: return "codice " + e;
        }
    }

    private void acquireWakeLock() {
        runOnUiThread(() -> {
            if (wakeLock != null && wakeLock.isHeld()) return;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AudioScribeAI:Processing");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(30 * 60 * 1000L);
        });
    }

    private void releaseWakeLock() {
        runOnUiThread(() -> {
            if (wakeLock != null && wakeLock.isHeld()) {
                try { wakeLock.release(); } catch (Exception ignored) {}
            }
        });
    }

    private static void closeQuietly(ParcelFileDescriptor pfd) {
        if (pfd != null) {
            try { pfd.close(); } catch (IOException ignored) {}
        }
    }

    @Override
    protected void onDestroy() {
        stopTranscription("Trascrizione interrotta.");
        cleanupRecognizer();
        worker.shutdownNow();
        releaseWakeLock();
        super.onDestroy();
    }
}

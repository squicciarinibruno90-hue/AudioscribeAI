package com.vilma.audioscribe;

import android.content.Context;

import com.google.mlkit.genai.common.DownloadCallback;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.common.GenAiException;
import com.google.mlkit.genai.prompt.GenerateContentRequest;
import com.google.mlkit.genai.prompt.GenerateContentResponse;
import com.google.mlkit.genai.prompt.Generation;
import com.google.mlkit.genai.prompt.GenerativeModel;
import com.google.mlkit.genai.prompt.TextPart;
import com.google.mlkit.genai.prompt.java.GenerativeModelFutures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Uses Gemini Nano through Android AICore. No OpenAI key or paid API is used. */
public final class TranscriptCleaner implements AutoCloseable {
    public interface StatusCallback {
        void onStatus(String message);
        void onProgress(int current, int total);
    }

    private final GenerativeModel model;
    private final GenerativeModelFutures futures;

    public TranscriptCleaner(Context context) {
        model = Generation.INSTANCE.getClient();
        futures = GenerativeModelFutures.from(model);
    }

    public int checkStatus() throws Exception {
        return futures.checkStatus().get(30, TimeUnit.SECONDS);
    }

    private void ensureReady(StatusCallback cb) throws Exception {
        int status = checkStatus();
        if (status == FeatureStatus.AVAILABLE) return;
        if (status == FeatureStatus.UNAVAILABLE) {
            throw new IllegalStateException("Gemini Nano non è disponibile in AICore su questo dispositivo/configurazione.");
        }
        if (status == FeatureStatus.DOWNLOADABLE || status == FeatureStatus.DOWNLOADING) {
            if (cb != null) cb.onStatus("Preparazione del modello AI locale…");
            futures.download(new DownloadCallback() {
                @Override public void onDownloadStarted(long bytesToDownload) {
                    if (cb != null) cb.onStatus("Download del modello AI locale…");
                }
                @Override public void onDownloadProgress(long totalBytesDownloaded) {
                    if (cb != null) cb.onStatus("Download AI: " + MediaUtils.formatBytes(totalBytesDownloaded));
                }
                @Override public void onDownloadCompleted() {
                    if (cb != null) cb.onStatus("Modello AI pronto.");
                }
                @Override public void onDownloadFailed(GenAiException e) {
                    if (cb != null) cb.onStatus("Download AI non riuscito: " + e.getMessage());
                }
            }).get(20, TimeUnit.MINUTES);
        }
        int after = checkStatus();
        if (after != FeatureStatus.AVAILABLE) {
            throw new IllegalStateException("Il modello AI locale non è ancora disponibile.");
        }
    }

    public String clean(String transcript, String glossary, StatusCallback cb) throws Exception {
        if (transcript == null || transcript.trim().isEmpty()) return "";
        ensureReady(cb);
        List<String> chunks = splitIntoChunks(transcript, 5600);
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < chunks.size(); i++) {
            if (cb != null) {
                cb.onProgress(i + 1, chunks.size());
                cb.onStatus("Pulizia AI del blocco " + (i + 1) + " di " + chunks.size() + "…");
            }
            String prompt = buildPrompt(chunks.get(i), glossary, i, chunks.size());
            GenerateContentRequest.Builder builder = new GenerateContentRequest.Builder(new TextPart(prompt));
            builder.setTemperature(0.1f);
            builder.setTopK(8);
            builder.setCandidateCount(1);
            builder.setMaxOutputTokens(4096);
            GenerateContentResponse response = futures.generateContent(builder.build())
                    .get(8, TimeUnit.MINUTES);
            if (response.getCandidates().isEmpty()) {
                throw new IllegalStateException("L'AI locale non ha restituito testo.");
            }
            String cleaned = response.getCandidates().get(0).getText();
            if (cleaned == null || cleaned.trim().isEmpty()) cleaned = chunks.get(i);
            if (result.length() > 0) result.append("\n\n");
            result.append(cleaned.trim());
        }
        return result.toString().trim();
    }

    private static String buildPrompt(String chunk, String glossary, int index, int total) {
        String g = glossary == null ? "" : glossary.trim();
        return "Sei un correttore di trascrizioni universitarie in lingua italiana. " +
                "Correggi ESCLUSIVAMENTE la trascrizione riportata sotto. " +
                "Regole obbligatorie: mantieni integralmente tutti i contenuti e le idee espresse; " +
                "NON riassumere; NON aggiungere spiegazioni o informazioni nuove; NON cambiare il significato; " +
                "correggi errori evidenti del riconoscimento vocale usando il contesto; sistema punteggiatura, maiuscole e paragrafi; " +
                "rimuovi solo esitazioni/intercalari e ripetizioni chiaramente accidentali; conserva esempi, elenchi, citazioni e nomi; " +
                "se una parola resta davvero incerta, scrivila come [termine incerto] invece di inventarla. " +
                "Restituisci SOLTANTO il testo corretto, senza prefazioni e senza commenti.\n\n" +
                (g.isEmpty() ? "" : "Glossario di termini da riconoscere e preservare:\n" + g + "\n\n") +
                "Blocco " + (index + 1) + " di " + total + ":\n---\n" + chunk + "\n---";
    }

    private static List<String> splitIntoChunks(String text, int maxChars) {
        String normalized = text.replace("\r\n", "\n").trim();
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < normalized.length()) {
            int end = Math.min(normalized.length(), start + maxChars);
            if (end < normalized.length()) {
                int paragraph = normalized.lastIndexOf("\n\n", end);
                int sentence = Math.max(normalized.lastIndexOf(". ", end), normalized.lastIndexOf("? ", end));
                sentence = Math.max(sentence, normalized.lastIndexOf("! ", end));
                int candidate = paragraph > start + maxChars / 2 ? paragraph + 2
                        : (sentence > start + maxChars / 2 ? sentence + 2 : end);
                end = candidate;
            }
            out.add(normalized.substring(start, end).trim());
            start = end;
            while (start < normalized.length() && Character.isWhitespace(normalized.charAt(start))) start++;
        }
        return out;
    }

    /** Conservative non-generative fallback if AICore is unavailable. */
    public static String basicCleanup(String text, String glossary) {
        if (text == null) return "";
        String s = text.replace('\u00A0', ' ')
                .replaceAll("[ \\t]+", " ")
                .replaceAll(" *\\n *", "\n")
                .replaceAll("\\n{3,}", "\n\n")
                .replaceAll(" +([,.;:!?])", "$1")
                .trim();

        List<String> canonicalTerms = new ArrayList<>(Arrays.asList(
                "Universal Design for Learning", "CAST", "ICF", "ICD-H", "PEI",
                "Capability Approach", "Disability Studies", "Evidence-Based Education",
                "evidence-based education", "facilitatori", "barriere", "funzionamenti",
                "capacitazione", "capacitazioni", "Sen", "Nussbaum", "UNESCO"
        ));
        if (glossary != null && !glossary.trim().isEmpty()) {
            for (String term : glossary.split("[,;\\n]")) {
                term = term.trim();
                if (!term.isEmpty()) canonicalTerms.add(term);
            }
        }
        for (String term : canonicalTerms) {
            Pattern p = Pattern.compile(Pattern.quote(term), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            Matcher m = p.matcher(s);
            s = m.replaceAll(Matcher.quoteReplacement(term));
        }
        if (!s.isEmpty()) s = Character.toUpperCase(s.charAt(0)) + s.substring(1);
        return s;
    }

    @Override public void close() {
        try { model.close(); } catch (Exception ignored) {}
    }
}

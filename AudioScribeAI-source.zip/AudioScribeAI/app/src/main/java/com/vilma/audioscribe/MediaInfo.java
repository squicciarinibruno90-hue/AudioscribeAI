package com.vilma.audioscribe;

public final class MediaInfo {
    public final String displayName;
    public final long sizeBytes;
    public final long durationMs;
    public final int width;
    public final int height;

    public MediaInfo(String displayName, long sizeBytes, long durationMs, int width, int height) {
        this.displayName = displayName;
        this.sizeBytes = sizeBytes;
        this.durationMs = durationMs;
        this.width = width;
        this.height = height;
    }
}

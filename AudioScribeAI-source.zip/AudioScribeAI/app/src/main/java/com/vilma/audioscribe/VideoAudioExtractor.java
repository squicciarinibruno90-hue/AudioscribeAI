package com.vilma.audioscribe;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

public final class VideoAudioExtractor {
    public interface ProgressListener {
        void onProgress(int percent);
    }

    private VideoAudioExtractor() {}

    /**
     * Copies the compressed audio track out of the selected video into an MP4/M4A container.
     * No full-file buffering and no audio re-encoding are performed.
     */
    public static File extract(Context context, Uri inputUri, File outputFile,
                               ProgressListener listener) throws IOException {
        MediaExtractor extractor = new MediaExtractor();
        MediaMuxer muxer = null;
        boolean muxerStarted = false;
        try {
            extractor.setDataSource(context, inputUri, null);
            int audioTrack = -1;
            MediaFormat audioFormat = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    audioFormat = f;
                    break;
                }
            }
            if (audioTrack < 0 || audioFormat == null) {
                throw new IOException("Il video non contiene una traccia audio leggibile.");
            }

            String mime = audioFormat.getString(MediaFormat.KEY_MIME);
            // MediaMuxer MP4 reliably supports AAC from normal phone recordings.
            if (mime == null || !(mime.equals(MediaFormat.MIMETYPE_AUDIO_AAC)
                    || mime.equals("audio/mp4a-latm"))) {
                throw new IOException("Formato audio del video non supportato per l'estrazione rapida: " + mime);
            }

            if (outputFile.exists() && !outputFile.delete()) {
                throw new IOException("Impossibile sostituire il file audio temporaneo.");
            }
            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("Impossibile creare la cartella temporanea.");
            }

            muxer = new MediaMuxer(outputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int outTrack = muxer.addTrack(audioFormat);
            muxer.start();
            muxerStarted = true;
            extractor.selectTrack(audioTrack);

            int maxInput = audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)
                    ? audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                    : 1024 * 1024;
            maxInput = Math.max(maxInput, 256 * 1024);
            ByteBuffer buffer = ByteBuffer.allocateDirect(maxInput);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long durationUs = audioFormat.containsKey(MediaFormat.KEY_DURATION)
                    ? audioFormat.getLong(MediaFormat.KEY_DURATION) : -1L;
            int lastPercent = -1;

            while (true) {
                buffer.clear();
                int size = extractor.readSampleData(buffer, 0);
                if (size < 0) break;
                long timeUs = extractor.getSampleTime();
                int flags = extractor.getSampleFlags();
                info.set(0, size, Math.max(0L, timeUs), flags);
                muxer.writeSampleData(outTrack, buffer, info);

                if (durationUs > 0 && listener != null && timeUs >= 0) {
                    int p = (int) Math.min(99, (timeUs * 100L) / durationUs);
                    if (p != lastPercent) {
                        listener.onProgress(p);
                        lastPercent = p;
                    }
                }
                if (!extractor.advance()) break;
            }
            if (listener != null) listener.onProgress(100);
            return outputFile;
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (muxer != null) {
                try { if (muxerStarted) muxer.stop(); } catch (Exception ignored) {}
                try { muxer.release(); } catch (Exception ignored) {}
            }
        }
    }
}

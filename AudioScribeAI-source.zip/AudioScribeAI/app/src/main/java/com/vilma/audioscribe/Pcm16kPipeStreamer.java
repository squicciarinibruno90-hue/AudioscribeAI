package com.vilma.audioscribe;

import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Decodes an audio file with Android MediaCodec, downmixes to mono, resamples to 16 kHz
 * and writes raw headerless PCM16 into a pipe at approximately real-time speed.
 */
public final class Pcm16kPipeStreamer {
    public interface ProgressListener {
        void onProgress(int percent);
    }

    private static final int TARGET_RATE = 16_000;
    private static final int PCM_CHUNK_SAMPLES = 1_600; // 100 ms

    private Pcm16kPipeStreamer() {}

    public static void stream(File inputAudio,
                              ParcelFileDescriptor writeSide,
                              ProgressListener listener) throws Exception {
        try (OutputStream pipeOut = new ParcelFileDescriptor.AutoCloseOutputStream(writeSide)) {
            decodeAndStream(inputAudio, pipeOut, listener);
        }
    }

    private static void decodeAndStream(File inputAudio,
                                        OutputStream pipeOut,
                                        ProgressListener listener) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec decoder = null;
        try {
            extractor.setDataSource(inputAudio.getAbsolutePath());
            int track = findAudioTrack(extractor);
            if (track < 0) throw new IOException("Nessuna traccia audio da trascrivere.");
            extractor.selectTrack(track);
            MediaFormat inputFormat = extractor.getTrackFormat(track);
            String mime = inputFormat.getString(MediaFormat.KEY_MIME);
            if (mime == null) throw new IOException("Formato audio sconosciuto.");
            long durationUs = inputFormat.containsKey(MediaFormat.KEY_DURATION)
                    ? inputFormat.getLong(MediaFormat.KEY_DURATION) : -1L;

            decoder = MediaCodec.createDecoderByType(mime);
            decoder.configure(inputFormat, null, null, 0);
            decoder.start();

            boolean inputDone = false;
            boolean outputDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int sourceRate = inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 48_000;
            int channels = inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
            int pcmEncoding = AudioFormat.ENCODING_PCM_16BIT;

            RealTimePcmWriter writer = new RealTimePcmWriter(pipeOut);
            SampleRateConverter converter = new SampleRateConverter(writer);
            int lastProgress = -1;

            while (!outputDone) {
                if (!inputDone) {
                    int inputIndex = decoder.dequeueInputBuffer(10_000);
                    if (inputIndex >= 0) {
                        ByteBuffer in = decoder.getInputBuffer(inputIndex);
                        if (in == null) throw new IOException("Decoder audio non disponibile.");
                        in.clear();
                        int size = extractor.readSampleData(in, 0);
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            long pts = Math.max(0L, extractor.getSampleTime());
                            decoder.queueInputBuffer(inputIndex, 0, size, pts, 0);
                            extractor.advance();
                            if (durationUs > 0 && listener != null) {
                                int p = (int) Math.min(99, (pts * 100L) / durationUs);
                                if (p != lastProgress) {
                                    listener.onProgress(p);
                                    lastProgress = p;
                                }
                            }
                        }
                    }
                }

                int outputIndex = decoder.dequeueOutputBuffer(info, 10_000);
                if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat outFmt = decoder.getOutputFormat();
                    if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sourceRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                    if (outFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        pcmEncoding = outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING);
                    }
                } else if (outputIndex >= 0) {
                    ByteBuffer out = decoder.getOutputBuffer(outputIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        ByteBuffer slice = out.slice().order(ByteOrder.LITTLE_ENDIAN);
                        converter.consume(slice, sourceRate, channels, pcmEncoding);
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    decoder.releaseOutputBuffer(outputIndex, false);
                }
            }
            converter.finish();
            if (listener != null) listener.onProgress(100);
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (decoder != null) {
                try { decoder.stop(); } catch (Exception ignored) {}
                try { decoder.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static int findAudioTrack(MediaExtractor extractor) {
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat f = extractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) return i;
        }
        return -1;
    }

    private static final class SampleRateConverter {
        private final RealTimePcmWriter writer;
        private long accumulator = 0;

        SampleRateConverter(RealTimePcmWriter writer) {
            this.writer = writer;
        }

        void consume(ByteBuffer data, int sourceRate, int channels, int encoding) throws Exception {
            if (sourceRate <= 0) sourceRate = 48_000;
            if (channels <= 0) channels = 1;

            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                consumeFloat(data, sourceRate, channels);
            } else {
                // Android audio decoders normally output PCM16 unless float output is requested.
                consumePcm16(data, sourceRate, channels);
            }
        }

        private void consumePcm16(ByteBuffer data, int sourceRate, int channels) throws Exception {
            int bytesPerFrame = 2 * channels;
            int frameCount = data.remaining() / bytesPerFrame;
            for (int frame = 0; frame < frameCount; frame++) {
                int sum = 0;
                for (int ch = 0; ch < channels; ch++) sum += data.getShort();
                short mono = clampToShort(sum / channels);
                resample(mono, sourceRate);
            }
        }

        private void consumeFloat(ByteBuffer data, int sourceRate, int channels) throws Exception {
            int bytesPerFrame = 4 * channels;
            int frameCount = data.remaining() / bytesPerFrame;
            for (int frame = 0; frame < frameCount; frame++) {
                float sum = 0f;
                for (int ch = 0; ch < channels; ch++) sum += data.getFloat();
                float monoF = Math.max(-1f, Math.min(1f, sum / channels));
                short mono = (short) Math.round(monoF * 32767f);
                resample(mono, sourceRate);
            }
        }

        private void resample(short sample, int sourceRate) throws Exception {
            accumulator += TARGET_RATE;
            while (accumulator >= sourceRate) {
                writer.writeSample(sample);
                accumulator -= sourceRate;
            }
        }

        void finish() throws Exception {
            writer.finish();
        }

        private static short clampToShort(int v) {
            if (v > Short.MAX_VALUE) return Short.MAX_VALUE;
            if (v < Short.MIN_VALUE) return Short.MIN_VALUE;
            return (short) v;
        }
    }

    private static final class RealTimePcmWriter {
        private final OutputStream out;
        private final byte[] buffer = new byte[PCM_CHUNK_SAMPLES * 2];
        private int pos = 0;
        private long samplesWritten = 0;
        private final long startNs = SystemClock.elapsedRealtimeNanos();

        RealTimePcmWriter(OutputStream out) {
            this.out = out;
        }

        void writeSample(short s) throws Exception {
            buffer[pos++] = (byte) (s & 0xFF);
            buffer[pos++] = (byte) ((s >>> 8) & 0xFF);
            if (pos == buffer.length) flushChunk();
        }

        private void flushChunk() throws Exception {
            if (pos == 0) return;
            out.write(buffer, 0, pos);
            out.flush();
            samplesWritten += pos / 2L;
            pos = 0;
            pace();
        }

        void finish() throws Exception {
            flushChunk();
            out.flush();
        }

        private void pace() throws InterruptedException {
            long targetNs = startNs + (samplesWritten * 1_000_000_000L) / TARGET_RATE;
            while (true) {
                long remainingNs = targetNs - SystemClock.elapsedRealtimeNanos();
                if (remainingNs <= 0) return;
                long ms = remainingNs / 1_000_000L;
                int ns = (int) (remainingNs % 1_000_000L);
                Thread.sleep(ms, ns);
            }
        }
    }
}

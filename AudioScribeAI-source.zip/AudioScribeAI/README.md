# AudioScribe AI

Android app designed for Xiaomi 15T / Android 13+.

## Main flow

1. Pick a video directly from the Android photo picker (video thumbnails/preview).
2. Preview the selected video.
3. Extract its audio without loading the whole video into RAM. For common phone videos with AAC audio, the audio track is copied losslessly into an M4A/MP4 audio container.
4. Transcribe locally by injecting decoded 16 kHz mono PCM into Android's on-device `SpeechRecognizer` in segmented mode.
5. Edit/copy/save the transcript.
6. Clean the transcript with on-device Gemini Nano through ML Kit Prompt API when available (Xiaomi 15T is supported by Google's current device list).
7. Preserve the original transcript separately from the AI-cleaned version.

## Important notes

- No artificial 250/300 MB video limit: processing is streaming, not an in-memory upload.
- The app does not send the video to an app server.
- Speech recognition support depends on the on-device recognition service installed on the phone. The app prefers the on-device recognizer.
- The audio stream sent to the speech recognizer is deliberately paced in real time for compatibility, so a 15-minute recording can take about 15 minutes to transcribe.
- Gemini Nano is managed by Android AICore. On first use, AICore may need to download model assets. No OpenAI API key is used.
- GenAI Prompt API is currently a beta API, so future Android/ML Kit updates can require dependency or code updates.

## Build

Open the project in current Android Studio and build `app` as a debug APK, or push to GitHub and run the included **Build Android APK** workflow.

Requirements:
- JDK 17
- Android SDK 36
- Android Gradle Plugin 8.13.2
- Gradle 8.13
